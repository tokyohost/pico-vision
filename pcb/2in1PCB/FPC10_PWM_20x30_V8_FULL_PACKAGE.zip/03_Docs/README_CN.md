# FPC10 + PWM 20×30 mm 转接板 V8

## V8 FPC 编号方向修正

- FPC 顶视图从左往右固定为 **1～10脚**。
- **FPC 1脚 = LED- / LEDK**，并连接 AO3400A 的漏极。
- **FPC 3脚 = GND**，对应原小板 LED- 旁边的 GND。
- J2 两排编号也按顶视图从左往右排列：上排 1～5，下排 6～10。
- 沿用 V7 已验证的电路、线宽、间距、孔位和 PWM 元件数量，仅校正水平方向与丝印标识。

## 结构

- 板框：**20.00 × 30.00 mm**，双层。
- 固定孔：4 × **M2.2 非金属化孔**。
- J1：10P、1.0 mm、下接触 FPC，插入口朝 20 mm 板边。
- J2：2×5、2.54 mm 通孔，10 路按编号一一引出。
- J3：独立 `PWM / GND` 两针控制口。
- PWM 元件仅有：Q1=AO3400A、R1=100 Ω、R2=10 kΩ。

## 引脚定义

| Pin | 名称 | 说明 |
|---:|---|---|
| 1 | LEDK / LED- | 背光负极，同时接 AO3400A 漏极 |
| 2 | LEDA | 背光正极，本板没有串联限流电阻 |
| 3 | GND | 地，位于 LED- 旁边 |
| 4 | SDO | 屏幕串行输出，可不接 |
| 5 | SDA | SPI MOSI |
| 6 | CS | 片选 |
| 7 | DC | 数据/命令 |
| 8 | SCL | SPI 时钟 |
| 9 | RST | 复位 |
| 10 | VDD | 屏幕逻辑电源，按 3.3 V 使用 |

J3-1 为 3.3 V PWM 输入，J3-2 为 GND。

## 下单前检查

1. 在嘉立创顶层预览中确认 FPC 左端标记为 1，右端标记为 10。
2. 确认排线从板框上边插入，FPC 插座为 10P、1.0 mm、下接触。
3. 本板没有背光恒流或限流电阻；裸屏背光若未内置限流，LEDA 不能直接接电源。
4. 建议首次只下单 5 片样板并限流上电。

## 文件

- `01_JLCPCB_Order/FPC10_PWM_20x30_V8_GERBER.zip`：嘉立创下单文件。
- `01_JLCPCB_Order/BOM_JLCPCB.csv`：SMT BOM。
- `01_JLCPCB_Order/CPL_JLCPCB.csv`：贴片坐标。
- `02_Source/FPC10_PWM_20x30_V8.kicad_pcb`：KiCad PCB 源文件。
- `03_Docs/preview_top.png`：顶层走线与正常方向丝印。
- `03_Docs/preview_bottom.png`：底层走线。
- `03_Docs/gerber_orientation_check.png`：Gerber CAM 顶视图检查。
